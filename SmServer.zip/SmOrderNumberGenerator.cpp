#include "pch.h"
#include "SmOrderNumberGenerator.h"
int SmOrderNumberGenerator::_ID = 0;
