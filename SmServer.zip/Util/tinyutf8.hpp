#ifndef TINY_UTF8_FORWARD_DECLARE_ONLY
#define TINY_UTF8_FORWARD_DECLARE_ONLY true
#endif

#include "tinyutf8.h"
