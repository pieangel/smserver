#pragma once
#include "Global/TemplateSingleton.h"
class ]mAccountOrderManger : public TemplateSingleton<SmAccountOrderManger>
{
public:
	SmAccountOrderManger();
	~SmAccountOrderManger();
};

