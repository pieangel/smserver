#include "pch.h"
#include "SmUser.h"

void SmUser::Reset()
{
	_Socket = nullptr;
	_Connected = false;
}
